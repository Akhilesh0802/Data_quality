"""
PDF to Excel (XLSX) / CSV Converter
-----------------------------------
Extracts tables from text-based PDFs into XLSX or CSV.

Usage:
  GUI : python pdf_to_excel.py
  CLI : python pdf_to_excel.py input.pdf -o output.xlsx
        python pdf_to_excel.py input.pdf -o out.csv --pages 1-3,5
        python pdf_to_excel.py input.pdf -o out.xlsx --mode separate --password secret

Install:
  pip install pdfplumber pandas openpyxl
"""

import argparse
import os
import re
import sys
import threading
import time
from datetime import datetime

import pandas as pd
import pdfplumber

# Strategies tried in order: ruled tables first, then whitespace-aligned tables
STRATEGIES = [
    {"vertical_strategy": "lines", "horizontal_strategy": "lines"},
    # min_words_vertical=2: sparse columns (e.g. Credit with few entries) still
    # get their own column instead of merging into the neighbour (default is 3)
    {"vertical_strategy": "text", "horizontal_strategy": "text",
     "min_words_vertical": 2},
]
MAX_ROWS = 1_000_000  # stay under Excel's 1,048,576-row sheet limit


# ---------------------------------------------------------------- core logic
def parse_pages(spec, total):
    """'1-3,5' -> [0,1,2,4] (0-based). Empty -> all pages."""
    if not spec or not spec.strip():
        return list(range(total))
    pages = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            pages.update(range(int(a), int(b) + 1))
        elif part:
            pages.add(int(part))
    return sorted(p - 1 for p in pages if 1 <= p <= total)


NUM_RE = re.compile(r"^\(?-?(₹|Rs\.?|INR)?\s?-?[\d,]*\.?\d+\)?$", re.I)
LEADING_ZERO_RE = re.compile(r"^0\d")  # 000123, 0042 -> IDs, must stay text


def clean_rows(rows, min_cols=2):
    """Normalise cells, drop empty rows and fully-empty columns.
    Returns a list of equal-length string rows, or None."""
    rows = [[(c or "").replace("\n", " ").strip() for c in r] for r in rows]
    rows = [r for r in rows if any(r)]
    if not rows:
        return None
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    keep = [c for c in range(width) if any(r[c] for r in rows)]
    rows = [[r[c] for c in keep] for r in rows]
    return rows if len(keep) >= min_cols else None


def is_number(cell):
    return bool(NUM_RE.match(cell.replace(" ", ""))) if cell else False


def looks_like_header(row):
    """Header = no numeric cells and at least half the cells filled."""
    filled = [c for c in row if c]
    return (len(filled) * 2 >= len(row)
            and not any(is_number(c) for c in filled))


def unique_header(row):
    """Blank -> ColN, duplicates -> Name_2, Name_3 ..."""
    out, seen = [], {}
    for i, h in enumerate(row):
        h = h or f"Col{i + 1}"
        if h in seen:
            seen[h] += 1
            h = f"{h}_{seen[h]}"
        else:
            seen[h] = 1
        out.append(h)
    return out


def to_number(cell):
    s = re.sub(r"(₹|Rs\.?|INR|,|\s)", "", cell, flags=re.I)
    s = re.sub(r"^\((.*)\)$", r"-\1", s)  # (500) -> -500
    return pd.to_numeric(s, errors="coerce")


def build_df(header, data):
    df = pd.DataFrame(data, columns=header)
    # Convert a column to numbers only if EVERY non-blank cell is numeric
    # and none has a leading zero (account no., PIN, employee ID stay text).
    for col in df.columns:
        vals = [v for v in df[col] if v != ""]
        if (vals and all(is_number(v) for v in vals)
                and not any(LEADING_ZERO_RE.match(v.lstrip("₹").strip())
                            for v in vals)):
            df[col] = [to_number(v) if v != "" else None for v in df[col]]
    return df


def words_intact(rows, page_words):
    """For borderless detection: reject 'tables' that split words in half
    (that happens when plain paragraphs are mistaken for a table)."""
    tokens = [t for r in rows for c in r for t in c.split()]
    if not tokens:
        return False
    return sum(t in page_words for t in tokens) / len(tokens) >= 0.9


class RunLog:
    """Writes every step to a .log file; mirrors important lines to screen.

    step(msg)   -> log file + screen (GUI box / console)
    detail(msg) -> log file only (per-page/per-table detail, keeps screen clean)
    """

    def __init__(self, path, ui=print):
        self.path, self.ui = path, ui
        self.f = open(path, "w", encoding="utf-8") if path else None
        self.warnings = 0

    def _write(self, level, msg):
        if self.f:
            self.f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} | {level:<5} | {msg}\n")
            self.f.flush()  # log survives even if the app crashes mid-run

    def step(self, msg):
        self._write("INFO", msg)
        self.ui(msg)

    def detail(self, msg):
        self._write("INFO", msg)

    def warn(self, msg):
        self.warnings += 1
        self._write("WARN", msg)
        self.ui("WARNING: " + msg)

    def error(self, msg):
        self._write("ERROR", msg)
        self.ui("ERROR: " + msg)

    def close(self):
        if self.f:
            self.f.close()
            self.f = None


def find_page_tables(page, log, pg):
    """Returns (list_of_raw_rows_tables, strategy_name) for one page."""
    words = None
    for strat in STRATEGIES:
        is_text = strat["vertical_strategy"] == "text"
        got = []
        for raw in page.extract_tables(table_settings=strat):
            rows = clean_rows(raw, min_cols=2 if is_text else 1)
            if not rows:
                continue
            if is_text:
                if len(rows) < 2:
                    continue
                if words is None:
                    words = {w["text"] for w in page.extract_words()}
                if not words_intact(rows, words):
                    log.detail(f"Page {pg}: ignored a borderless 'table' that "
                               f"splits words (looks like normal paragraphs)")
                    continue
            elif len(rows[0]) == 1 and len(rows) < 2:
                continue  # a lone boxed cell, not a table
            got.append(rows)
        if got:
            return got, strat["vertical_strategy"]
    return [], "-"


def extract_tables(pdf_path, pages=None, password=None, log=None):
    """Returns list of (start_page, table_idx, DataFrame, row_pages).
    A table that runs over several pages is stitched into ONE table."""
    log = log or RunLog(None)
    tables = []  # working dicts, turned into DataFrames at the end
    log.step("Step 2/4: Opening PDF")
    with pdfplumber.open(pdf_path, password=password) as pdf:
        log.detail(f"PDF opened{' (password used)' if password else ''}; "
                   f"total pages in file: {len(pdf.pages)}")
        idxs = parse_pages(pages, len(pdf.pages))
        if not idxs:
            raise ValueError(f"Page range '{pages}' has no valid pages "
                             f"(PDF has {len(pdf.pages)} pages).")
        log.step(f"Step 3/4: Extracting tables from {len(idxs)} page(s)")
        total, start = len(idxs), time.time()
        for n, i in enumerate(idxs, 1):
            pg = i + 1
            page = pdf.pages[i]
            found, used = [], "-"
            try:
                found, used = find_page_tables(page, log, pg)
                if not found:
                    if (page.extract_text() or "").strip():
                        log.detail(f"Page {pg}: text present but no table detected")
                    elif page.images:
                        log.warn(f"Page {pg}: page is an image (scanned) - "
                                 f"needs OCR, no text to extract")
                    else:
                        log.detail(f"Page {pg}: blank page")
            except Exception as e:  # one bad page shouldn't kill a 1000-page run
                log.warn(f"Page {pg}: skipped ({type(e).__name__}: {e})")
            finally:
                page.close()  # free cached page objects -> flat memory on big PDFs

            for k, rows in enumerate(found):
                # Does the first table on this page continue the last table
                # of the previous page? (same column count, consecutive page)
                prev = tables[-1] if tables else None
                if (k == 0 and prev and prev["last_page"] == pg - 1
                        and len(rows[0]) == len(prev["header"])):
                    if prev["header_raw"] and rows[0] == prev["header_raw"]:
                        rows, how = rows[1:], "header repeated, dropped"
                    elif looks_like_header(rows[0]):
                        how = None  # its own header -> a new table
                    else:
                        how = "no header on this page"
                    if how:
                        prev["rows"] += rows
                        prev["row_pages"] += [pg] * len(rows)
                        prev["last_page"] = pg
                        log.detail(f"Page {pg} table 1: continues table from "
                                   f"page {prev['page']} ({how}), +{len(rows)} rows")
                        continue
                has_h = looks_like_header(rows[0])
                header = (unique_header(rows[0]) if has_h
                          else [f"Col{c + 1}" for c in range(len(rows[0]))])
                data = rows[1:] if has_h else rows
                idx = sum(1 for t in tables if t["page"] == pg) + 1
                tables.append(dict(page=pg, idx=idx, header=header,
                                   header_raw=rows[0] if has_h else None,
                                   rows=data, row_pages=[pg] * len(data),
                                   last_page=pg))
                log.detail(f"Page {pg} table {idx}: {len(data)} rows x "
                           f"{len(header)} cols (strategy: {used}) "
                           f"header={'yes' if has_h else 'no -> Col1..'} "
                           f"columns={header}")
            if not found:
                log.detail(f"Page {pg}: 0 tables")
            if n == total or n % 25 == 0 or total <= 50:
                eta = (time.time() - start) / n * (total - n)
                log.step(f"[{n}/{total}] page {pg}: {len(found)} table(s)"
                         f"  | ETA {eta:.0f}s")

    results = []
    for t in tables:
        df = build_df(t["header"], t["rows"])
        results.append((t["page"], t["idx"], df, t["row_pages"]))
        span = (f"pages {t['page']}-{t['last_page']}"
                if t["last_page"] != t["page"] else f"page {t['page']}")
        log.detail(f"Final table P{t['page']}_T{t['idx']}: {span}, "
                   f"{len(df)} rows, numeric columns="
                   f"{[c for c in df.columns if df[c].dtype != object]}")
        if not t["rows"]:
            log.warn(f"Table P{t['page']}_T{t['idx']} has a header but no data rows")
    log.step(f"Extraction finished: {len(results)} table(s), "
             f"{sum(len(r[2]) for r in results)} rows in "
             f"{time.time() - start:.1f}s")
    return results


def save(tables, out_path, mode="combined", log=None):
    """mode='combined' -> one sheet/CSV; 'separate' -> sheet/CSV per table."""
    log = log or RunLog(None)
    if not tables:
        raise ValueError("No tables found in the selected pages.")
    log.step(f"Step 4/4: Writing output ({mode} mode)")
    ext = os.path.splitext(out_path)[1].lower()
    written = []

    if mode == "combined":
        frames = []
        for p, t, df, row_pages in tables:
            df = df.copy()
            df.insert(0, "Table", f"P{p}_T{t}")
            df.insert(0, "Page", row_pages)  # real page of each row
            frames.append(df)
        shapes = {tuple(df.columns) for _, _, df, _ in tables}
        if len(shapes) > 1:
            log.warn(f"Tables have {len(shapes)} different column layouts; "
                     f"Combined sheet will have many empty cells. "
                     f"'Separate per table' mode is better for this PDF.")
        combined = pd.concat([f for f in frames if len(f)] or frames,
                             ignore_index=True, sort=False)
        if ext == ".csv":
            combined.to_csv(out_path, index=False, encoding="utf-8-sig")
        else:
            with pd.ExcelWriter(out_path, engine="openpyxl") as w:
                # Excel caps a sheet at 1,048,576 rows -> spill into extra sheets
                for k, s in enumerate(range(0, max(len(combined), 1), MAX_ROWS), 1):
                    name = "All Tables" if k == 1 else f"All Tables {k}"
                    chunk = combined.iloc[s:s + MAX_ROWS]
                    chunk.to_excel(w, sheet_name=name, index=False)
                    autofit(w.sheets[name])
                    log.detail(f"Sheet '{name}': {len(chunk)} rows")
        log.detail(f"Combined {len(tables)} tables -> {len(combined)} rows, "
                   f"{combined.shape[1]} columns")
        written.append(out_path)
    else:
        if ext == ".csv":
            base = os.path.splitext(out_path)[0]
            for p, t, df, _ in tables:
                path = f"{base}_p{p}_t{t}.csv"
                df.to_csv(path, index=False, encoding="utf-8-sig")
                written.append(path)
                log.detail(f"Wrote {path} ({len(df)} rows)")
        else:
            with pd.ExcelWriter(out_path, engine="openpyxl") as w:
                for p, t, df, _ in tables:
                    # a stitched multi-page table can pass Excel's row limit
                    for k, s in enumerate(range(0, max(len(df), 1), MAX_ROWS), 1):
                        name = f"P{p}_T{t}" + ("" if k == 1 else f"_{k}")
                        chunk = df.iloc[s:s + MAX_ROWS]
                        chunk.to_excel(w, sheet_name=name, index=False)
                        autofit(w.sheets[name])
                        log.detail(f"Sheet '{name}': {len(chunk)} rows")
            written.append(out_path)
    for f in written:
        log.detail(f"Saved: {f} ({os.path.getsize(f) / 1024:.1f} KB)")
    return written


def autofit(ws):
    from openpyxl.styles import Font
    for cell in ws[1]:
        cell.font = Font(bold=True)
    ws.freeze_panes = "A2"
    for col in ws.columns:
        width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[col[0].column_letter].width = min(width + 2, 60)


def log_path_for(out):
    return os.path.splitext(out)[0] + "_log.txt"


OUTPUT_DIR_NAME = "output"


def output_dir_for(pdf):
    """<folder of the PDF>/output"""
    return os.path.join(os.path.dirname(os.path.abspath(pdf)), OUTPUT_DIR_NAME)


def auto_output_path(pdf, ext="xlsx"):
    """Output goes in an 'output' subfolder next to the input PDF.
    Desktop/statement.pdf -> Desktop/output/statement.xlsx (+ statement_log.txt).
    Creates the folder if missing; reuses it if it already exists.
    If a file with that name exists, adds a timestamp so nothing is overwritten."""
    out_dir = output_dir_for(pdf)
    os.makedirs(out_dir, exist_ok=True)
    name = os.path.splitext(os.path.basename(pdf))[0]
    base = os.path.join(out_dir, name)

    def taken(stem):
        # the output, its log, or any separate-mode CSV (<stem>_p1_t1.csv) clashes
        return (os.path.exists(f"{stem}.{ext}") or os.path.exists(f"{stem}_log.txt")
                or any(f.startswith(os.path.basename(stem) + "_p")
                       and f.endswith(".csv") for f in os.listdir(out_dir)
                       if ext == "csv"))

    if not taken(base):
        return f"{base}.{ext}"
    stamped = f"{base}_{datetime.now():%Y%m%d_%H%M%S}"
    stem, n = stamped, 2
    while taken(stem):  # two runs in the same second -> _2, _3, ...
        stem, n = f"{stamped}_{n}", n + 1
    return f"{stem}.{ext}"


def open_folder(path):
    """Open a folder in Explorer / Finder / file manager."""
    if sys.platform.startswith("win"):
        os.startfile(path)
    elif sys.platform == "darwin":
        import subprocess
        subprocess.Popen(["open", path])
    else:
        import subprocess
        subprocess.Popen(["xdg-open", path])


def convert(pdf, out, pages=None, mode="combined", password=None, ui=print,
            log_file=None):
    """Runs the conversion; always writes a step-by-step log file.
    Returns (output_files, log_file_path)."""
    log_file = log_file or log_path_for(out)
    log = RunLog(log_file, ui)
    t0 = time.time()
    try:
        log.step("Step 1/4: Validating inputs")
        log.detail(f"Input PDF : {os.path.abspath(pdf)}")
        if not os.path.isfile(pdf):
            raise FileNotFoundError(f"Input PDF not found: {pdf}")
        if os.path.getsize(pdf) == 0:
            raise ValueError("File is empty (0 bytes). Check the PDF and try again.")
        log.detail(f"PDF size  : {os.path.getsize(pdf) / 1024 / 1024:.2f} MB")
        log.detail(f"Output    : {os.path.abspath(out)}")
        log.detail(f"Format    : {os.path.splitext(out)[1].lstrip('.').upper()}")
        log.detail(f"Mode      : {mode}")
        log.detail(f"Pages     : {pages or 'all'}")
        log.detail(f"Password  : {'provided' if password else 'none'}")  # never log the value

        tables = extract_tables(pdf, pages, password, log)
        files = save(tables, out, mode, log)
        log.step(f"Done in {time.time() - t0:.1f}s: {len(tables)} table(s) -> "
                 f"{', '.join(files)} | warnings: {log.warnings}")
        log.step(f"Log file: {log_file}")
        return files, log_file
    except Exception as e:
        msg = str(e) or type(e).__name__
        chain = f"{type(e).__name__} {e!r} {e.__cause__!r} {e.__context__!r}"
        if any(k in chain for k in ("No /Root", "PDFSyntaxError", "PSEOF",
                                    "Unexpected EOF", "is this really a PDF")):
            msg = "File is corrupt or not a valid PDF."
        elif "Password" in chain or "password" in chain or (
                type(e).__name__ == "PdfminerException" and not str(e)):
            msg = ("PDF is password-protected and the password is wrong or missing."
                   if password else
                   "PDF is password-protected. Enter its password and try again.")
        log.error(f"Failed after {time.time() - t0:.1f}s: {msg}")
        log.detail(f"Exception type: {type(e).__name__}")
        raise RuntimeError(msg) from e
    finally:
        log.close()


# ---------------------------------------------------------------- GUI
def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("PDF to Excel / CSV")
    root.geometry("620x440")

    pdf_var, folder_var = tk.StringVar(), tk.StringVar(value="(select a PDF)")
    pages_var, pwd_var = tk.StringVar(), tk.StringVar()
    fmt_var, mode_var = tk.StringVar(value="xlsx"), tk.StringVar(value="combined")

    def pick_pdf():
        f = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        if f:
            pdf_var.set(f)
            folder_var.set(output_dir_for(f))

    def log(msg):
        root.after(0, lambda: (logbox.insert("end", msg + "\n"), logbox.see("end")))

    def open_out_folder():
        target = folder_var.get()
        if not pdf_var.get():
            messagebox.showinfo("No folder", "Select a PDF first.")
        elif os.path.isdir(target):
            open_folder(target)
        else:  # nothing converted yet -> open the PDF's own folder
            open_folder(os.path.dirname(target))

    def start():
        pdf = pdf_var.get().strip()
        if not pdf or not os.path.isfile(pdf):
            messagebox.showwarning("Missing", "Select an input PDF.")
            return
        out = auto_output_path(pdf, fmt_var.get())  # same folder as the PDF
        log_file = log_path_for(out)
        btn.config(state="disabled")
        logbox.delete("1.0", "end")

        def work():
            try:
                files, _ = convert(pdf, out, pages_var.get(), mode_var.get(),
                                   pwd_var.get() or None, ui=log, log_file=log_file)
                names = "\n".join(os.path.basename(f) for f in files)
                root.after(0, lambda: messagebox.showinfo(
                    "Done", f"Saved in {os.path.dirname(out)}:\n\n{names}\n"
                            f"{os.path.basename(log_file)}"))
            except Exception as e:
                err = str(e)
                root.after(0, lambda: messagebox.showerror(
                    "Error", f"{err}\n\nDetails in log:\n{log_file}"))
            finally:
                root.after(0, lambda: btn.config(state="normal"))

        threading.Thread(target=work, daemon=True).start()

    frm = ttk.Frame(root, padding=12)
    frm.pack(fill="both", expand=True)
    frm.columnconfigure(1, weight=1)

    ttk.Label(frm, text="Input PDF").grid(row=0, column=0, sticky="w")
    ttk.Entry(frm, textvariable=pdf_var).grid(row=0, column=1, sticky="ew", padx=6)
    ttk.Button(frm, text="Browse", command=pick_pdf).grid(row=0, column=2)

    ttk.Label(frm, text="Saves to").grid(row=1, column=0, sticky="w", pady=6)
    ttk.Label(frm, textvariable=folder_var, foreground="gray").grid(
        row=1, column=1, columnspan=2, sticky="w", padx=6)

    opts = ttk.Frame(frm)
    opts.grid(row=2, column=0, columnspan=3, sticky="w", pady=4)
    ttk.Label(opts, text="Format:").pack(side="left")
    for v in ("xlsx", "csv"):
        ttk.Radiobutton(opts, text=v.upper(), variable=fmt_var,
                        value=v).pack(side="left", padx=4)
    ttk.Label(opts, text="   Mode:").pack(side="left")
    ttk.Radiobutton(opts, text="Combined", variable=mode_var, value="combined").pack(side="left", padx=4)
    ttk.Radiobutton(opts, text="Separate per table", variable=mode_var, value="separate").pack(side="left")

    ttk.Label(opts, text="  (Separate = each table gets its own sheet/CSV)",
              foreground="gray").pack(side="left")

    ttk.Label(frm, text="Pages (e.g. 1-3,5)").grid(row=3, column=0, sticky="w")
    ttk.Entry(frm, textvariable=pages_var).grid(row=3, column=1, sticky="ew", padx=6)
    ttk.Label(frm, text="blank = all", foreground="gray").grid(row=3, column=2, sticky="w")
    ttk.Label(frm, text="Password").grid(row=4, column=0, sticky="w", pady=6)
    ttk.Entry(frm, textvariable=pwd_var, show="*").grid(row=4, column=1, sticky="ew", padx=6)
    ttk.Label(frm, text="only if PDF is locked", foreground="gray").grid(row=4, column=2, sticky="w")

    bar = ttk.Frame(frm)
    bar.grid(row=5, column=0, columnspan=3, pady=8)
    btn = ttk.Button(bar, text="Convert", command=start)
    btn.pack(side="left", padx=4)
    ttk.Button(bar, text="Open folder", command=open_out_folder).pack(side="left", padx=4)

    logbox = tk.Text(frm, height=10)
    logbox.grid(row=6, column=0, columnspan=3, sticky="nsew")
    frm.rowconfigure(6, weight=1)

    root.mainloop()


# ---------------------------------------------------------------- CLI
def main():
    if len(sys.argv) == 1:
        run_gui()
        return
    ap = argparse.ArgumentParser(description="Convert PDF tables to XLSX/CSV")
    ap.add_argument("pdf")
    ap.add_argument("-o", "--output", help="output .xlsx or .csv (default: <pdf>.xlsx)")
    ap.add_argument("--pages", help="e.g. 1-3,5 (default: all)")
    ap.add_argument("--mode", choices=["combined", "separate"], default="combined")
    ap.add_argument("--password", help="only needed for locked/encrypted PDFs")
    ap.add_argument("--log", help="log file path (default: <output>_log.txt)")
    a = ap.parse_args()
    out = a.output or auto_output_path(a.pdf, "xlsx")  # default: next to the PDF
    try:
        convert(a.pdf, out, a.pages, a.mode, a.password, log_file=a.log)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
