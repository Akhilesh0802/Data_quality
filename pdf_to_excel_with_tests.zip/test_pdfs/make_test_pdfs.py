"""
Generates edge-case PDFs for testing pdf_to_excel.py.
Run:  python make_test_pdfs.py      (needs: pip install reportlab pypdf pillow)
Creates PDFs in the same folder as this script.
"""
import os

from PIL import Image, ImageDraw, ImageFont
from pypdf import PdfReader, PdfWriter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (PageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

OUT = os.path.dirname(os.path.abspath(__file__))
GRID = TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                   ("FONTSIZE", (0, 0), (-1, -1), 8)])
NOGRID = TableStyle([("FONTSIZE", (0, 0), (-1, -1), 9),
                     ("LEFTPADDING", (0, 0), (-1, -1), 12)])
styles = getSampleStyleSheet()

UNI = "Helvetica"
for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
          "C:/Windows/Fonts/arial.ttf", "/Library/Fonts/Arial Unicode.ttf"]:
    if os.path.exists(p):
        pdfmetrics.registerFont(TTFont("Uni", p))
        UNI = "Uni"
        break


def build(name, story, pagesize=A4):
    SimpleDocTemplate(os.path.join(OUT, name), pagesize=pagesize,
                      topMargin=30, bottomMargin=30).build(story)
    print("made", name)


def para(t):
    return Paragraph(t, styles["Normal"])


# 01 simple bordered table
build("01_simple_bordered.pdf", [Table(
    [["Name", "Dept", "Salary"], ["Ravi", "IT", "50000"],
     ["Sita", "HR", "42000"], ["Amit", "Ops", "38000"]], style=GRID)])

# 02 borderless, whitespace-aligned (like many bank statements)
build("02_borderless.pdf", [Table(
    [["Date", "Narration", "Debit", "Credit", "Balance"],
     ["01-10-2026", "UPI/Swiggy", "450.00", "", "12,550.00"],
     ["02-10-2026", "Salary Oct", "", "85,000.00", "97,550.00"],
     ["03-10-2026", "ATM WDL", "2,000.00", "", "95,550.00"]], style=NOGRID)])

# 03 several tables on one page, with text between them
build("03_multiple_tables_one_page.pdf", [
    para("Section A - Employees"),
    Table([["Emp", "City"], ["Ravi", "Pune"], ["Sita", "Delhi"]], style=GRID),
    Spacer(1, 20), para("Section B - Invoices"),
    Table([["Invoice", "Amount"], ["INV-1", "1200"], ["INV-2", "800"]], style=GRID),
    Spacer(1, 20), para("Section C - Stock"),
    Table([["SKU", "Qty", "Rate"], ["A1", "5", "10.5"], ["B2", "7", "3.25"]], style=GRID)])

# 04 one long table split across pages, header repeated (repeatRows=1)
rows = [["TxnID", "Account", "Amount"]] + \
       [[f"T{i:04d}", f"AC{i:05d}", f"{i * 10.5:.2f}"] for i in range(1, 121)]
build("04_table_across_pages_header_repeated.pdf",
      [Table(rows, style=GRID, repeatRows=1)])

# 05 same long table but header ONLY on first page
build("05_table_across_pages_no_repeat.pdf", [Table(rows, style=GRID)])

# 06 multi-line wrapped cells + merged (spanned) cells
wrap = ParagraphStyleCell = styles["Normal"]
t = Table([["Region", "Q1", "Q2"],
           ["North (spans 2 rows)", "100", "120"],
           ["", "110", "130"],
           [Paragraph("South region including Karnataka, Kerala and Tamil Nadu "
                      "with a long wrapped description", wrap), "90", "95"],
           ["Total (spans 3 cols)", "", ""]],
          colWidths=[200, 60, 60],
          style=TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                            ("SPAN", (0, 1), (0, 2)), ("SPAN", (0, 4), (2, 4))]))
build("06_merged_and_wrapped_cells.pdf", [t])

# 07 empty cells / blank rows / blank column in the middle
build("07_empty_cells.pdf", [Table(
    [["ID", "Name", "", "Phone"], ["1", "Ravi", "", ""], ["", "", "", ""],
     ["3", "", "", "98765"], ["4", "Amit", "", "91234"]], style=GRID)])

# 08 tricky values: leading zeros, Indian commas, negatives, %, ₹, dates, IDs
build("08_tricky_numbers.pdf", [Table(
    [["AccountNo", "PinCode", "Amount", "Neg", "Pct", "Rupee", "Date", "Mixed"],
     ["000123", "560001", "1,20,000", "(500)", "12.5%", "₹1,500", "01/10/2026", "100"],
     ["004567", "110001", "95,000.50", "-250.75", "7%", "₹200", "15/10/2026", "N/A"],
     ["000089", "400001", "1,234", "-0", "100%", "₹0.50", "31/12/2026", "45"]],
    style=TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                      ("FONTNAME", (0, 0), (-1, -1), UNI),
                      ("FONTSIZE", (0, 0), (-1, -1), 8)]))])

# 09 duplicate / blank header names
build("09_duplicate_headers.pdf", [Table(
    [["Amount", "Amount", "", "Note"], ["10", "20", "x", "a"], ["30", "40", "y", "b"]],
    style=GRID)])

# 10 text only, no tables
build("10_no_tables_text_only.pdf",
      [para("This document has paragraphs only. " * 20) for _ in range(5)])

# 11 mixed: table / blank page / text / table
build("11_mixed_pages_with_blank.pdf", [
    Table([["A", "B"], ["1", "2"]], style=GRID), PageBreak(),
    Spacer(1, 1), PageBreak(),
    para("Only text on this page."), PageBreak(),
    Table([["C", "D"], ["3", "4"]], style=GRID)])

# 12 landscape page with a wide table (15 columns)
wide = [[f"Col{c}" for c in range(1, 16)]] + \
       [[f"r{r}c{c}" for c in range(1, 16)] for r in range(1, 6)]
build("12_landscape_wide_table.pdf", [Table(wide, style=GRID)],
      pagesize=landscape(A4))

# 13 single-column list (only 1 column)
build("13_single_column.pdf", [Table(
    [["Names"], ["Ravi"], ["Sita"], ["Amit"]], style=GRID)])

# 14 header row only, no data rows
build("14_header_only.pdf", [Table([["Name", "Dept", "Salary"]], style=GRID)])

# 15 scanned: page is an IMAGE of a table (no selectable text)
img = Image.new("RGB", (1240, 600), "white")
d = ImageDraw.Draw(img)
try:
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 32)
except OSError:
    f = ImageFont.load_default()
data = [["Name", "Dept", "Salary"], ["Ravi", "IT", "50000"], ["Sita", "HR", "42000"]]
for r, row in enumerate(data):
    for c, val in enumerate(row):
        x, y = 80 + c * 360, 80 + r * 120
        d.rectangle([x, y, x + 360, y + 120], outline="black", width=3)
        d.text((x + 20, y + 40), val, fill="black", font=f)
img.save(os.path.join(OUT, "15_scanned_image_only.pdf"), "PDF", resolution=150)
print("made 15_scanned_image_only.pdf")

# 16 password protected (password: test123)
w = PdfWriter()
for pg in PdfReader(os.path.join(OUT, "01_simple_bordered.pdf")).pages:
    w.add_page(pg)
w.encrypt("test123")
with open(os.path.join(OUT, "16_password_test123.pdf"), "wb") as fh:
    w.write(fh)
print("made 16_password_test123.pdf")

# 17 corrupt file (not really a PDF) and 18 empty 0-byte file
with open(os.path.join(OUT, "17_corrupt.pdf"), "wb") as fh:
    fh.write(b"%PDF-1.4\nthis is garbage, not a real pdf\n")
open(os.path.join(OUT, "18_empty_0_bytes.pdf"), "wb").close()
print("made 17_corrupt.pdf, 18_empty_0_bytes.pdf")

# 19 file name with spaces + special characters
build("19 file name (with) spaces & symbols.pdf",
      [Table([["X", "Y"], ["1", "2"]], style=GRID)])

# 20 different table structure on every page (for Combined mode)
build("20_different_columns_per_page.pdf", [
    Table([["Name", "Age"], ["Ravi", "30"]], style=GRID), PageBreak(),
    Table([["City", "Pin", "State"], ["Pune", "411001", "MH"]], style=GRID), PageBreak(),
    Table([["Item", "Price"], ["Pen", "10"]], style=GRID)])
