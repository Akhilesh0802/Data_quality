"""
Automated edge-case tests for pdf_to_excel.py

Folder layout:
    pdf_to_excel.py
    test_pdfs/
        make_test_pdfs.py
        run_tests.py      <- this file
        01_....pdf ...

Run:
    cd test_pdfs
    python make_test_pdfs.py     (once, creates the PDFs)
    python run_tests.py
"""
import os
import shutil
import sys
import tempfile
import traceback

import openpyxl

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import pdf_to_excel as p  # noqa: E402

WORK = tempfile.mkdtemp(prefix="pdf2xl_tests_")
results = []


def run(name, mode="combined", ext="xlsx", password=None):
    """Copy PDF to a temp folder, convert, return (files, log_text)."""
    src = os.path.join(HERE, name)
    dst = os.path.join(WORK, name)
    shutil.copy(src, dst)
    out = p.auto_output_path(dst, ext)
    log_file = p.log_path_for(out)
    try:
        files, _ = p.convert(dst, out, mode=mode, password=password,
                             ui=lambda m: None, log_file=log_file)
        return files, open(log_file, encoding="utf-8").read(), None
    except Exception as e:
        return [], open(log_file, encoding="utf-8").read(), str(e)


def sheets(path):
    """{sheet_name: [rows as tuples]} read raw (no pandas NA guessing)."""
    wb = openpyxl.load_workbook(path)
    return {ws.title: [r for r in ws.iter_rows(values_only=True)] for ws in wb}


def col(rows, name):
    i = rows[0].index(name)
    return [r[i] for r in rows[1:]]


def case(title):
    def deco(fn):
        try:
            fn()
            results.append(("PASS", title, ""))
        except AssertionError as e:
            results.append(("FAIL", title, str(e)))
        except Exception:
            results.append(("ERROR", title, traceback.format_exc(limit=1).strip()))
        return fn
    return deco


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


# ---------------------------------------------------------------- cases
@case("01 simple bordered table")
def _():
    f, _, err = run("01_simple_bordered.pdf")
    rows = sheets(f[0])["All Tables"]
    check(err is None, err)
    check(rows[0][2:] == ("Name", "Dept", "Salary"), f"header {rows[0]}")
    check(len(rows) == 4, f"expected 3 data rows, got {len(rows) - 1}")
    check(col(rows, "Salary") == [50000, 42000, 38000], "Salary not numeric")


@case("02 borderless table (Debit/Credit kept separate)")
def _():
    f, _, err = run("02_borderless.pdf")
    rows = sheets(f[0])["All Tables"]
    check("Debit" in rows[0] and "Credit" in rows[0], f"columns merged: {rows[0]}")
    check(col(rows, "Credit")[1] == 85000, f"credit wrong: {col(rows, 'Credit')}")
    check(col(rows, "Debit")[1] in (None, ""), "salary landed in Debit")
    check(col(rows, "Balance")[0] == 12550, "Indian/western commas not parsed")


@case("03 three tables on one page")
def _():
    f, _, err = run("03_multiple_tables_one_page.pdf", mode="separate")
    s = sheets(f[0])
    check(list(s) == ["P1_T1", "P1_T2", "P1_T3"], f"sheets {list(s)}")
    check(col(s["P1_T3"], "Rate") == [10.5, 3.25], "Rate wrong")


@case("04 table across pages, header repeated -> one table")
def _():
    f, log, err = run("04_table_across_pages_header_repeated.pdf", mode="separate")
    s = sheets(f[0])
    check(list(s) == ["P1_T1"], f"expected 1 stitched table, got {list(s)}")
    ids = col(s["P1_T1"], "TxnID")
    check(len(ids) == 120 and ids[-1] == "T0120", f"rows {len(ids)}")
    check("TxnID" not in ids, "repeated header leaked into data")


@case("05 table across pages, header only on page 1")
def _():
    f, log, err = run("05_table_across_pages_no_repeat.pdf", mode="separate")
    s = sheets(f[0])
    check(list(s) == ["P1_T1"], f"expected 1 stitched table, got {list(s)}")
    rows = s["P1_T1"]
    check(rows[0] == ("TxnID", "Account", "Amount"), f"header {rows[0]}")
    check(len(rows) - 1 == 120, f"expected 120 rows, got {len(rows) - 1}")


@case("05b combined mode keeps the real page number per row")
def _():
    f, _, _ = run("05_table_across_pages_no_repeat.pdf")
    rows = sheets(f[0])["All Tables"]
    pages = col(rows, "Page")
    check(pages[0] == 1 and pages[-1] == 3, f"pages {pages[0]}..{pages[-1]}")


@case("06 merged + wrapped cells")
def _():
    f, _, err = run("06_merged_and_wrapped_cells.pdf")
    rows = sheets(f[0])["All Tables"]
    reg = col(rows, "Region")
    check(any("Tamil Nadu" in (r or "") and "description" in (r or "") for r in reg),
          "wrapped text not kept in one cell")
    check(col(rows, "Q1")[:3] == [100, 110, 90], f"Q1 {col(rows, 'Q1')}")


@case("07 empty cells, blank row, blank column")
def _():
    f, _, err = run("07_empty_cells.pdf")
    rows = sheets(f[0])["All Tables"]
    check(rows[0][2:] == ("ID", "Name", "Phone"), f"header {rows[0]}")
    check(len(rows) - 1 == 3, "blank row not dropped")


@case("08 tricky values (leading zeros, (500), Rs, N/A)")
def _():
    f, _, err = run("08_tricky_numbers.pdf")
    rows = sheets(f[0])["All Tables"]
    check(col(rows, "AccountNo") == ["000123", "004567", "000089"],
          f"leading zeros lost: {col(rows, 'AccountNo')}")
    check(col(rows, "Amount") == [120000, 95000.5, 1234], "Amount")
    check(col(rows, "Neg")[:2] == [-500, -250.75], "negatives")
    check(col(rows, "Rupee") == [1500, 200, 0.5], f"rupee {col(rows, 'Rupee')}")
    check("N/A" in col(rows, "Mixed"), "N/A text lost")


@case("09 duplicate + blank header names")
def _():
    f, _, err = run("09_duplicate_headers.pdf")
    rows = sheets(f[0])["All Tables"]
    check(rows[0][2:] == ("Amount", "Amount_2", "Col3", "Note"), f"{rows[0]}")
    check(len(rows) - 1 == 2, "header row leaked into data")


@case("10 text-only PDF -> clear 'no tables' error, no garbage")
def _():
    f, log, err = run("10_no_tables_text_only.pdf")
    check(err and "No tables" in err, f"expected no-tables error, got {err}")


@case("11 mixed pages incl. blank page")
def _():
    f, log, err = run("11_mixed_pages_with_blank.pdf", mode="separate")
    check(list(sheets(f[0])) == ["P1_T1", "P4_T1"], "wrong tables")
    check("blank page" in log and "scanned" not in log, "blank page mislabelled")


@case("12 landscape wide table (15 cols)")
def _():
    f, _, err = run("12_landscape_wide_table.pdf")
    rows = sheets(f[0])["All Tables"]
    check(len(rows[0]) - 2 == 15 and len(rows) - 1 == 5, f"{len(rows[0])}x{len(rows)}")


@case("13 single-column list")
def _():
    f, _, err = run("13_single_column.pdf")
    check(err is None, err)
    rows = sheets(f[0])["All Tables"]
    check(col(rows, "Names") == ["Ravi", "Sita", "Amit"], f"{rows}")


@case("14 header only, no data")
def _():
    f, log, err = run("14_header_only.pdf")
    check(err is None, err)
    rows = sheets(f[0])["All Tables"]
    check(rows[0][2:] == ("Name", "Dept", "Salary") and len(rows) == 1, f"{rows}")
    check("no data rows" in log, "no warning logged")


@case("15 scanned image PDF -> OCR warning")
def _():
    f, log, err = run("15_scanned_image_only.pdf")
    check(err and "No tables" in err, err)
    check("scanned" in log and "OCR" in log, "no OCR hint in log")


@case("16 password: right / wrong / missing")
def _():
    f, _, err = run("16_password_test123.pdf", password="test123")
    check(err is None, f"right password failed: {err}")
    _, _, err = run("16_password_test123.pdf", password="nope")
    check(err and "wrong" in err, f"wrong pwd msg: {err}")
    _, _, err = run("16_password_test123.pdf")
    check(err and "password-protected" in err, f"missing pwd msg: {err}")


@case("17 corrupt file -> friendly error")
def _():
    _, _, err = run("17_corrupt.pdf")
    check(err and "corrupt" in err, err)


@case("18 empty 0-byte file -> friendly error")
def _():
    _, _, err = run("18_empty_0_bytes.pdf")
    check(err and "empty" in err, err)


@case("19 file name with spaces and symbols")
def _():
    f, _, err = run("19 file name (with) spaces & symbols.pdf")
    check(err is None and os.path.isfile(f[0]), err)


@case("20 different columns per page -> warning in combined mode")
def _():
    f, log, err = run("20_different_columns_per_page.pdf")
    check("different column layouts" in log, "no layout warning")
    f, _, _ = run("20_different_columns_per_page.pdf", mode="separate")
    check(len(sheets(f[0])) == 3, "separate mode should give 3 sheets")


@case("21 CSV separate mode -> one CSV per table in output/")
def _():
    f, _, err = run("03_multiple_tables_one_page.pdf", mode="separate", ext="csv")
    check(len(f) == 3 and all(x.endswith(".csv") for x in f), f"{f}")
    check(all(os.path.basename(os.path.dirname(x)) == "output" for x in f), "not in output/")


@case("22 page range '2' on 3-page table")
def _():
    src = os.path.join(HERE, "04_table_across_pages_header_repeated.pdf")
    dst = os.path.join(WORK, "range.pdf")
    shutil.copy(src, dst)
    out = p.auto_output_path(dst)
    files, _ = p.convert(dst, out, pages="2", ui=lambda m: None)
    rows = sheets(files[0])["All Tables"]
    check(set(col(rows, "Page")) == {2}, "rows from other pages")


# ---------------------------------------------------------------- report
w = max(len(t) for _, t, _ in results)
print()
for status, title, msg in results:
    print(f"[{status:5}] {title:<{w}}  {msg}")
passed = sum(s == "PASS" for s, _, _ in results)
print(f"\n{passed}/{len(results)} passed   (outputs in {WORK})")
sys.exit(0 if passed == len(results) else 1)
