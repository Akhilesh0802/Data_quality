PDF to Excel / CSV Tool
=======================

Option A - .exe banana (recommended, ek baar ka kaam)
  1. Is folder me "build_exe.bat" pe double-click karo.
  2. 1-3 minute me "PDF_to_Excel.exe" isi folder me ban jayegi.
  3. Ab sirf PDF_to_Excel.exe pe double-click karke tool kholo.
     Is .exe ko kisi bhi folder / kisi bhi Windows PC pe copy kar sakte ho,
     wahan Python ki zaroorat nahi.
  (Build ke liye ek baar Python chahiye: https://www.python.org/downloads/
   install karte waqt "Add Python to PATH" tick karna.)

Option B - bina .exe ke seedha chalana
  "run_tool.bat" pe double-click karo. Pehli baar packages install honge,
  phir tool khul jayega. Isme har baar Python chahiye.

Output
  Input PDF ke folder me "output" folder banega, usme:
    <pdf name>.xlsx (ya .csv)  +  <pdf name>_log.txt

Testing (optional)
  cd test_pdfs
  python make_test_pdfs.py
  python run_tests.py
