@echo off
REM ============================================================
REM  Double-click to open the PDF to Excel tool (needs Python).
REM  First run installs the packages automatically.
REM  Keep this file in the same folder as pdf_to_excel.py
REM ============================================================
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo Python not found. Install it from https://www.python.org/downloads/
    echo and tick "Add Python to PATH". Or use PDF_to_Excel.exe instead.
    pause
    exit /b 1
)

python -c "import pdfplumber, pandas, openpyxl" >nul 2>nul
if errorlevel 1 (
    echo First run: installing required packages...
    python -m pip install pdfplumber pandas openpyxl
    if errorlevel 1 (
        echo Package install failed. Check internet connection.
        pause
        exit /b 1
    )
)

REM pythonw = no black console window behind the app
start "" pythonw "%~dp0pdf_to_excel.py"
