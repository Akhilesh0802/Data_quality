@echo off
REM ============================================================
REM  Builds PDF_to_Excel.exe (double-click app, no Python needed
REM  to RUN it later). Needs Python only for this one-time build.
REM  Keep this file in the same folder as pdf_to_excel.py
REM ============================================================
cd /d "%~dp0"
title Building PDF_to_Excel.exe

where python >nul 2>nul
if errorlevel 1 (
    echo Python not found. Install it from https://www.python.org/downloads/
    echo and tick "Add Python to PATH" during install. Then run this again.
    pause
    exit /b 1
)

echo [1/3] Installing required packages...
python -m pip install --upgrade pdfplumber pandas openpyxl pyinstaller
if errorlevel 1 goto :fail

echo [2/3] Building the .exe (takes 1-3 minutes)...
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
    --name PDF_to_Excel ^
    --collect-data pdfminer ^
    --hidden-import openpyxl ^
    pdf_to_excel.py
if errorlevel 1 goto :fail

echo [3/3] Cleaning up...
copy /y "dist\PDF_to_Excel.exe" "PDF_to_Excel.exe" >nul
rmdir /s /q build >nul 2>nul
rmdir /s /q dist >nul 2>nul
del /q PDF_to_Excel.spec >nul 2>nul

echo.
echo Done! PDF_to_Excel.exe is ready in this folder:
echo   %~dp0PDF_to_Excel.exe
echo Double-click it to open the tool. You can copy it anywhere.
pause
exit /b 0

:fail
echo.
echo Build failed. Scroll up to see the error.
pause
exit /b 1
